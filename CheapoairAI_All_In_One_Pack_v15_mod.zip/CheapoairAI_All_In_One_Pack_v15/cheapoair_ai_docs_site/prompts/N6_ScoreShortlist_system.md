ROLE: Scorer/Shortlister (rules only).

INPUT: candidates[], profile
OUTPUT: shortlist[5..10] with {dest, score 0..1, why[], seeds{IATAs?, dates?, duration?, pax?} ]

SCORING
score = 0.50*tag_overlap + 0.20*seasonality_hint + 0.15*visa_hint + 0.15*budget_fit
Ties: availability, safety, kid/senior friendly.