# Cheapoair.AI — Milestone 1 & 2 Documentation
**Version:** v0.9 • **Date:** 2025-08-20 • **Owners:** AI COE (Search & Personalization), Platform, CX

---

## TL;DR
- **M1 (Intent & Entities + Session Profile):** Extract key trip facts (origins, dates/duration, pax, budget, cabin, domestic/international), store in a canonical **SessionProfile** with provenance and confidence. Ask at most **one** clarifying question when critical slots are missing.
- **M2 (Persona Tagging + Destination Matching):** Multi-label persona/interest tagging → internet-first destination shortlist (**Phase 1**). Later, swap in our **Destination Knowledge Base** + vector retrieval (**Phase 2**) with the same contract.
- **Architecture:** Multi-agent graph with clear contracts, JSON-only I/O, Redis (state), Postgres (canonical truth), Vector DB (pgvector) for embeddings. Internet research → Normalize → Rank → Explain.
- **Acceptance:** M1 F1 ≥ 0.90 on critical slots; M2 human relevance@5 ≥ 0.70; shortlist CTR ≥ 15%; p95 E2E latency < 2s (cache warm).
- **Privacy:** PII separated, minimal retention, user-controlled clearing.

---

## 1) Goals & Non‑Goals
### 1.1 Goals
- Extract trip facts fast and reliably.
- Build a **composable tag taxonomy** covering personas, interests, constraints.
- Produce **5–10 destination suggestions** with clear “why this” reasons.
- Map tags → concrete search params for flights/hotels/cars.
- Log everything with provenance for analytics and learning.
- Keep **Phase 1** internet-first; enable seamless migration to **Phase 2** (our KB).

### 1.2 Non‑Goals (v1)
- Full price prediction or optimal booking windows.
- Complex multi-city path optimization.
- Visa/legal guarantees (we provide **hints**, not legal advice).
- Real-time inventory integration (handled by downstream Cheapoair search).

---

## 2) Tag Taxonomy v0.1
**Structural**: PAX_*, DURATION_D, BUDGET_LOW/MID/HIGH, DOMESTIC/INTERNATIONAL, CABIN, DATE_EXACT/DATE_WINDOW, NONSTOP_ONLY, STOPOVER_OK, BAGGAGE_NEEDED, ACCESSIBILITY_WHEELCHAIR, PET_TRAVEL, WORK_FROM_ANYWHERE.
**Persona/Purpose**: LEISURE, BUSINESS, BLEISURE; PARTY: FAMILY, COUPLE, SOLO, FRIENDS.
**Style**: BUDGET_TRAVEL, LUXURY, ECO, WELLNESS, CULTURE, NIGHTLIFE.
**Themes**: BEACH, HILLS, DESERT, JUNGLE, CITY_BREAK, WINTER_SPORTS, WILDLIFE.
**Adventure**: ADVENTURE_WATER, ADVENTURE_TREK, ADVENTURE_SNOW, ADVENTURE_MOTO.
**Constraints**: VEG_FRIENDLY, HALAL_FRIENDLY, ALCOHOL_FREE, KID_FRIENDLY, SENIOR_FRIENDLY.

**Design rules**: flat, composable, deterministic. Each tag maps to (a) filters, (b) weights, (c) search params.

---

## 3) System Architecture (Phase 1 → Phase 2)
```
User
  ↓
Orchestrator (stateful, policy router)
  ├─ N1 Parse & Extract
  ├─ N2 Tag & Persona
  ├─ N3 Profile Manager
  ├─ N4 Clarify Gate (conditional)
  ├─ N5 CandidateGen (Tag Search via WebSearchSvc)
  ├─ N6 Score & Shortlist
  └─ N7 Compose Reply
Services: WebSearchSvc, GeoIataSvc, RulesSvc, TelemetrySvc, SafetyMiddleware
Stores: Redis (SessionProfileV3), Postgres (UserProfileV3/analytics)
```

**Phase 2 (swap in):**
- KB-Retriever (replaces WebSearchSvc for candidate generation)
- Ranker/Personalizer upgrades (vectors/bandit)
- KB pipeline: crawler → parser → auto-tagger → vectorizer → QA → publisher
---


## 4) Data Contracts (JSON)

### 4.1 SessionProfile (canonical)
See `schemas/session_profile.schema.json` in this pack.
Key fields: `facts`, `preferences`, `personas`, `tags[]`, `provenance[]`, confidences.

### 4.2 DestinationRecord (KB row)
See `schemas/destination_record.schema.json`. Covers place metadata, seasonality, visa, cost index, tags, embedding.

### 4.3 Events
- `profile.updated` — track merges and provenance.
- `destinations.shortlist` — track suggestions shown.
- `user.choice` — track clicks/intents for learning.

Contracts in `contracts/events.examples.json`.

---

## 5) Nodes & Services (Phase 1 — Lean)

**LangGraph Nodes (on-demand; not always sequential):**
- **N1 Parse & Extract** — pre-parser + JSON extractor; outputs strict `facts` + confidences.
- **N2 Tag & Persona** — multi-label tagging (dimensioned taxonomy) with weights & rationales.
- **N3 Profile Manager** — deterministic merge into `SessionProfileV3`; provenance; versioning.
- **N4 Clarify Gate** — if critical slots missing/low-conf → ask one question and STOP.
- **N5 CandidateGen (Tag Search)** — craft “fun” high-recall queries from tags/time/budget; call WebSearchSvc.
- **N6 Score & Shortlist** — compute signals & score; produce 5–10 with “why” and search seeds.
- **N7 Compose Reply** — map tags→params and compose user-facing answer; Safety middleware applies.

**Services (separate deployables):**
- **WebSearchSvc** (metasearch + scrape + cache)
- **GeoIataSvc** (city↔IATA, regions)
- **RulesSvc** (seasonality, visa hints, cost index)
- **TelemetrySvc** (events → warehouse)
- **SafetyMiddleware** (PII redaction, disclaimers)

### 5.1 Optional Enrichment Jobs (async)
`visa_enrich`, `seasonality_enrich`, `budget_enrich` — fire-and-forget; workers update SessionProfileV3 and emit `profile.updated`.

Visa rules, Seasonality/Climate, Budget band estimator, IATA/Geo resolver, Safety advisory.

---

## 6) Node I/O Contracts (samples)

### N1 (Parse & Extract)
Input:
```json
{"user_msg":"We are 2 adults from DEL for 6 days late Oct, mid budget","session_id":"..."}
```
Output:
```json
{"intent":"plan_trip","entities":{"origins":["DEL"],"duration_days":6,"date_window_days":7,"pax":{"adults":2,"children":0,"infants":0},"budget_band":"mid"},"confidence":0.93}
```

### N2 (Tag & Persona)
Output (append-only; keep probs):
```json
{"tags":[{"name":"COUPLE","p":0.66},{"name":"BEACH","p":0.78},{"name":"ADVENTURE_WATER","p":0.72},{"name":"BUDGET_MID","p":0.83}],"rationale":["mentions 'wife'","scuba","mid budget"]}
```

### N6 (Score & Shortlist) item
```json
{"dest":"Phuket","score":0.81,"why":["BEACH","ADVENTURE_WATER","visa_on_arrival"],"search_seeds":{"IATAs":["HKT","KBV"],"dates":["2025-10-20±3d"],"duration":6,"pax":{"adults":2}}}
```

---

## 7) Matching & Scoring (Phase 1)
Candidate generation (A5→A6): collect 15–30 names; normalize; compute signals:
- `tag_overlap` (weighted Jaccard over persona/activity tags)
- `seasonality_fit` (date window vs best months)
- `visa_feasibility` (if nationality known; else hint)
- `budget_fit` (user band vs destination cost index)

**Score:**
```
score = 0.50*tag_overlap + 0.20*seasonality_fit +
        0.15*visa_feasibility + 0.15*budget_fit
```
Tie-breakers: flight availability, safety, kid/senior friendly.

**Phase 2 score (replace later):**
```
score = 0.45*cosine(user_vec, dest_vec) +
        0.25*tag_overlap + 0.10*seasonality +
        0.10*visa + 0.10*budget
```

---

## 8) Tag → Search Param Mapping (examples)

### Flights
- `NONSTOP_ONLY` → `stops=0`; else allow `<=1`.
- `FAMILY` → avoid redeye; connection MCT ≥ 60m.
- `BUDGET_LOW` → use LCC carriers; ±3d flex grid; cap by budget.
- `ADVENTURE_TREK` → enforce season windows (e.g., pre/post monsoon Himalayas).

### Hotels
- `KID_FRIENDLY` → pool, family room, breakfast.
- `COUPLE` → 4–5★, spa, privacy.
- `REMOTE_WORK_OK` → Wi‑Fi score, desk, proximity to coworking.

### Cars
- `ADVENTURE_MOTO` → scooter/bike where legal; else compact SUV.
- `FAMILY` → MPV/SUV; child seat flag.

---

## 9) Prompts & Schemas
Prompt stubs are in `prompts/`:
- `intent_extractor_prompt.md` — system + few-shot + JSON schema.
- `persona_classifier_prompt.md` — taxonomy-enforced multi-label classifier.

Use JSON mode / function-calling with validation; reject outputs not matching schema.

---

## 10) Orchestration (LangGraph pseudo)
```mermaid
flowchart TD
U[User]-->O[Orchestrator]
O-->N1
N1-->N2-->N3
N3-->N4
N4-- missing? -->Q[Ask 1 Q]-->STOP
N4-- ok -->N5-->N6-->N7-->R[Reply]
O-.->Safety
O-.->Telemetry
```
Retries: N5 (cache), N6 fallback weights. Short-circuit at N4 if critical data absent.

Retries: A5 (cache), A7 fallback weights. Short-circuit at A4 if critical data absent.

---

## 11) Evaluation
- **Extraction (A1):** F1 on origins, dates/duration, pax ≥ 0.90.
- **Tagging (A2):** micro-F1 ≥ 0.75; disagreement < 15%.
- **Shortlist (A7):** human relevance@5 ≥ 0.70; CTR ≥ 15%.
- **Latency:** p95 end-to-end < 2s (cache warm).
- **Drift:** monitor tag frequency & miss patterns; weekly review.

---

## 12) Telemetry & Events
Log: `profile.updated`, `destinations.shortlist`, `user.choice` (clicks), `search.performed`, `booking.signal`.
Aggregate in warehouse; dashboards for funnel, CTR by tag, latency by stage.

---

## 13) Privacy & Safety
- Store PII separately from SessionProfile; token-scoped access.
- User-triggered “forget me” deletes profile & events (soft delete TTL 7 days).
- Safety agent blocks disallowed content; visa disclaimers; regional compliance (GDPR/CCPA).

---

## 14) Deployment & Infra
- **Monorepo** with services: orchestrator, agents, profile store, research, ranker.
- **Runtime:** Node/TS or Python; Redis (session), Postgres (profiles/analytics), pgvector (KB).
- **Caching:** tag×month×budget keys for A5 results.
- **Feature flags:** switch A5 (web) ↔ M1’ (KB Retriever).

**Postgres (pgvector) example:**
```sql
CREATE EXTENSION IF NOT EXISTS vector;
CREATE TABLE destinations (
  id BIGSERIAL PRIMARY KEY,
  place_name TEXT, country TEXT,
  tags TEXT[],
  seasonality JSONB, visa JSONB,
  cost_index TEXT,
  embedding VECTOR(3072),
  kb_version TEXT DEFAULT 'v0'
);
CREATE INDEX ON destinations USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);
```

---

## 15) Backlog & Roadmap
- v0: Internet-first shortlist live; telemetry.
- v1: 100–200 KB destinations; M1’ retriever behind flag; AB with internet.
- v2: Ranker/bandit; personalization via history embeddings.
- v3: Expand KB, price curves, safety/comms; richer hotel/car params.

---

## 16) Appendix
### 16.1 Test prompts (quick)
- “2 adults, Delhi, 6 days in late Oct, love beaches & scuba, veg-friendly, mid budget.”
- “Family of 4 from NYC, spring break, wildlife + kid-friendly, domestic.”

### 16.2 Example reply format
- **Top picks:** Phuket, Bali, Andaman, Maldives, Goa
- **Why:** tag matches + seasonality + visa hint + budget
- **Next:** “Pick one or share dates/origin to search fares/hotels.”

---
