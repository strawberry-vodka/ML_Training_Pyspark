
const btn = document.getElementById('navToggle');
const nav = document.querySelector('.sidebar');
if(btn && nav){ btn.addEventListener('click', ()=> nav.classList.toggle('open')); }
